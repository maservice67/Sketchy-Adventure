const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Set canvas size
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Pencil character
const pencil = {
    x: 50,
    y: canvas.height / 2,
    width: 40,
    height: 40,
    color: "orange",
    speed: 5,
    dx: 0,
    dy: 0,
};

// Obstacles
let obstacles = [];
let score = 0;
let isGameOver = false;

// Add touch controls for Android
document.addEventListener("keydown", movePencil);
document.addEventListener("keyup", stopPencil);

function movePencil(e) {
    if (e.key === "ArrowUp") pencil.dy = -pencil.speed;
    if (e.key === "ArrowDown") pencil.dy = pencil.speed;
}

function stopPencil(e) {
    pencil.dx = 0;
    pencil.dy = 0;
}

// Generate obstacles
function createObstacle() {
    const size = Math.random() * 30 + 20;
    const obstacle = {
        x: canvas.width,
        y: Math.random() * canvas.height,
        width: size,
        height: size,
        color: "red",
        speed: 4,
    };
    obstacles.push(obstacle);
}

// Draw pencil
function drawPencil() {
    ctx.fillStyle = pencil.color;
    ctx.fillRect(pencil.x, pencil.y, pencil.width, pencil.height);
}

// Draw obstacles
function drawObstacles() {
    obstacles.forEach((obstacle) => {
        ctx.fillStyle = obstacle.color;
        ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    });
}

// Update obstacles
function updateObstacles() {
    obstacles.forEach((obstacle, index) => {
        obstacle.x -= obstacle.speed;

        // Check collision
        if (
            pencil.x < obstacle.x + obstacle.width &&
            pencil.x + pencil.width > obstacle.x &&
            pencil.y < obstacle.y + obstacle.height &&
            pencil.y + pencil.height > obstacle.y
        ) {
            isGameOver = true;
        }

        // Remove off-screen obstacles
        if (obstacle.x + obstacle.width < 0) {
            obstacles.splice(index, 1);
            score++;
        }
    });
}

// Update pencil position
function updatePencil() {
    pencil.x += pencil.dx;
    pencil.y += pencil.dy;

    // Prevent going off-screen
    if (pencil.y < 0) pencil.y = 0;
    if (pencil.y + pencil.height > canvas.height)
        pencil.y = canvas.height - pencil.height;
}

// Game over
function gameOver() {
    document.getElementById("restart").style.display = "block";
    ctx.fillStyle = "black";
    ctx.font = "36px Arial";
    ctx.fillText("Game Over", canvas.width / 2 - 100, canvas.height / 2);
}

// Restart game
function restartGame() {
    score = 0;
    isGameOver = false;
    obstacles = [];
    pencil.x = 50;
    pencil.y = canvas.height / 2;
    document.getElementById("restart").style.display = "none";
    requestAnimationFrame(gameLoop);
}

// Game loop
function gameLoop() {
    if (isGameOver) {
        gameOver();
        return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawPencil();
    drawObstacles();
    updatePencil();
    updateObstacles();

    // Display score
    document.getElementById("score").textContent = `Score: ${score}`;

    requestAnimationFrame(gameLoop);
}

// Spawn obstacles periodically
setInterval(createObstacle, 1500);

// Start the game
gameLoop();
